

<script>
    import "../style/app.css"
</script>

<slot></slot>